from base import Database



def insert():
    query = f""" INSERT INTO payment_type(name) VALUES('in cash')"""
    status = Database.connect("localhost", "pharmacy", "postgres", "Yulduz969696", query)
    print(status)
if __name__ == '__main__':
    insert()