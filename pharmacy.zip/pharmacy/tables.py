from base import Database

def create_city():
    query=f"""CREATE TABLE city(
    city_id SERIAL PRIMARY KEY,
    name VARCHAR(50),
    last_update TIMESTAMP DEFAULT NOW());
"""
    status=Database.connect("localhost","pharmacy","postgres","Yulduz969696",query)
    print(status)

def address():
    query = f"""CREATE TABLE address(
    address_id SERIAL PRIMARY KEY,
    name VARCHAR(50),
    city_id INT REFERENCES city(city_id),
    last_update TIMESTAMP DEFAULT NOW());
"""
    status = Database.connect("localhost", "pharmacy", "postgres", "Yulduz969696", query)
    print(status)

def pharmacy():
    query = f"""CREATE TABLE pharmacy(
    pharmacy_id SERIAL PRIMARY KEY,
    product_id INT REFERENCES prpduct(product_id),
    name VARCHAR(50),
    address_id INT REFERENCES address(address_id),
    work_start_time TIME,
    work_end_time TIME,
    last_update TIMESTAMP DEFAULT NOW())"""

    status=Database.connect("localhost","pharmacy","postgres","Yulduz969696",query)
    print(status)

def product():
    query = f"""CREATE TABLE product(
    name VARCHAR(50),
    product_id SERIAL PRIMARY KEY,
    description VARCHAR(50),
    start_date TIME,
    exp.date TIME,
    price NOT NULL,
    count NOT NULL,
    firma_id INT REFERENCES firma(firma_id),
    seria_id NOT  NULL)
"""
    status=Database.connect("localhost","pharmacy","postgres","Yulduz969696",query)
    print(status)

def firma():
    query = f"""CREATE TABLE firma(
    firma_id SERIAL PRIMARY KEY,
    name VARCHAR(30),
    address VARCHAR(30),
    location VARCHAR(30),
    phone_number INT)
"""
    status=Database.connect("localhost","pharmacy","postgres","Yulduz969696","Yulduz969696")
    print(status)

def payment():
    query = f"""CREATE TABLE payment(
    payment_id SERIAL PRIMARY KEY,
    amount NOT NULL,
    product_id INT REFERENCES produc(product_id),
    pharmacy_id INT REFERENCES pharmacy(pharmacy_id),
     payment_type_id REFERENCES payment_type(payment_type_id),
     staff_id INT REFERENCES staff(staff_id),
     payment_timestamp TIMESTAMP DEFAULT NOW())
     """

    status = Database.connect("localhost", "pharmacy", "postgres", "Yulduz969696", query)
    print(status)


def payment_type():
    query = f"""CREATE TABLE payment_type(
    payment_type_id SERIAL PRIMARY KEY,
    name VARCHAR(50),
    last_update TIMESTAMP DEFAULT NOW())
"""

    status = Database.connect("localhost", "pharmacy", "postgres", "Yulduz969696", query)
    print(status)


def staff():
    query = f""" CREATE TABLE staff(
    staff_id SERIAL PRIMARY KEY,
    first_name VARCHAR(50),
    last_name VARCHAR(50),
    birth_date NOT NULL,
    phone_number NOT NULL)
"""

    status = Database.connect("localhost", "pharmacy", "postgres", "Yulduz969696", query)
    print(status)


if __name__=="__main__":
    create_city()

