import psycopg2 as psql

class Database:
    @staticmethod
    def connect(host, database, user, password, query):
        postgrs_db = psql.connect(
            host=host,
            database=database,
            user=user,
            password=password,
        )

        cursor = postgrs_db.cursor()
        cursor.execute(query)
        postgrs_db.commit()
        return "Perfect "
